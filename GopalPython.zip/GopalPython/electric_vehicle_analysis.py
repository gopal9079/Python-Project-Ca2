import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import os

# Set the file path
file_path = r'C:\Users\dell\Desktop\New folder\electric_vehicle_data.csv'

# Check if file exists
if not os.path.exists(file_path):
    print('C:\Users\dell\Desktop\New folder\electric_vehicle_data.csv')
else:
    # Load the dataset
    df = pd.read_csv(file_path)

    # ----------------------------
    # DATA CLEANING
    # ----------------------------
    print("Initial Missing Values:\n", df.isnull().sum())

    # Strip whitespace from column names
    df.columns = df.columns.str.strip()

    # Drop rows with missing key values
    df.dropna(subset=['Make', 'Model', 'Electric Range', 'Model Year', 'Vehicle Type', 'County'], inplace=True)

    # Convert data types
    df['Electric Range'] = pd.to_numeric(df['Electric Range'], errors='coerce')
    df['Model Year'] = pd.to_numeric(df['Model Year'], errors='coerce')
    df.dropna(subset=['Electric Range', 'Model Year'], inplace=True)

    # ----------------------------
    # DATA ANALYSIS
    # ----------------------------
    # Number of EVs per manufacturer
    make_counts = df['Make'].value_counts()
    print("\nEVs per Manufacturer:\n", make_counts.head(10))

    # Most common models
    model_counts = df['Model'].value_counts()
    print("\nMost Common Models:\n", model_counts.head(10))

    # Distribution of vehicle types
    type_counts = df['Vehicle Type'].value_counts()
    print("\nVehicle Type Distribution:\n", type_counts)

    # Top counties by EV count
    county_counts = df['County'].value_counts()
    print("\nTop Counties by EV Count:\n", county_counts.head(10))

    # ----------------------------
    # DATA VISUALIZATION
    # ----------------------------
    plt.figure(figsize=(10, 6))
    sns.barplot(x=make_counts.head(10).values, y=make_counts.head(10).index, palette='viridis')
    plt.title("Top 10 Manufacturers by EV Count")
    plt.xlabel("Number of Vehicles")
    plt.ylabel("Manufacturer")
    plt.tight_layout()
    plt.show()

    plt.figure(figsize=(10, 6))
    sns.histplot(df['Electric Range'], bins=30, kde=True)
    plt.title("Distribution of Electric Range")
    plt.xlabel("Electric Range (miles)")
    plt.tight_layout()
    plt.show()

    plt.figure(figsize=(10, 6))
    sns.countplot(data=df, y='Vehicle Type', order=df['Vehicle Type'].value_counts().index, palette='Set2')
    plt.title("Electric Vehicle Type Distribution")
    plt.xlabel("Count")
    plt.ylabel("Vehicle Type")
    plt.tight_layout()
    plt.show()

    plt.figure(figsize=(10, 6))
    sns.countplot(data=df, x='Model Year', order=sorted(df['Model Year'].unique()))
    plt.title("EV Adoption Over Model Years")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

    # ----------------------------
    # FILTERING & QUERYING
    # ----------------------------
    # Example filters
    make_filter = df[df['Make'].str.upper() == 'TESLA']
    print("\nTESLA Vehicles:\n", make_filter[['Model', 'Electric Range', 'County']].head())

    range_filter = df[df['Electric Range'] > 100]
    print("\nVehicles with Electric Range > 100 miles:\n", range_filter[['Make', 'Model', 'Electric Range']].head())

    city_filter = df[df['County'].str.contains('King', na=False, case=False)]
    print("\nVehicles registered in 'King' County:\n", city_filter[['Make', 'Model', 'County']].head())

    # ----------------------------
    # SIMPLE TREND PREDICTION WITHOUT sklearn
    # ----------------------------
    avg_range_by_year = df.groupby('Model Year')['Electric Range'].mean().reset_index()

    # Basic Linear Prediction (using numpy polyfit)
    x = avg_range_by_year['Model Year'].values
    y = avg_range_by_year['Electric Range'].values
    coeffs = np.polyfit(x, y, deg=1)
    poly_eq = np.poly1d(coeffs)

    future_years = np.array([2025, 2026, 2027])
    predicted_ranges = poly_eq(future_years)

    print("\nPredicted Electric Range for Future Years:")
    for year, pred in zip(future_years, predicted_ranges):
        print(f"{year}: {pred:.2f} miles")

    # Plot trend and prediction
    plt.figure(figsize=(10, 6))
    plt.plot(x, y, 'bo-', label='Actual')
    plt.plot(future_years, predicted_ranges, 'ro--', label='Predicted')
    plt.xlabel("Model Year")
    plt.ylabel("Average Electric Range")
    plt.title("Trend and Future Prediction of Electric Range")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

