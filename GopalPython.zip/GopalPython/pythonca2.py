# Import required libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Set visualization style
sns.set(style="whitegrid")
plt.rcParams["figure.figsize"] = (12, 6)

# Load dataset
df = pd.read_csv("34_Details_Of_Assembly_Segment_Of_PC.csv")

# Display basic info and check for missing values
print("Dataset Info:\n")
print(df.info())
print("\nMissing Values:\n")
print(df.isnull().sum())

# Fill numeric missing values with the mean (if any)
df = df.fillna(df.mean(numeric_only=True))

# ---------------------------
# BASIC STATISTICS
# ---------------------------
print("\nSummary Statistics:\n")
print(df.describe())

# ---------------------------
# TOTAL ELECTORS VS TOTAL VOTES
# ---------------------------
df["Voter Turnout (%)"] = (df["Votes Secured Evm"] / df["Total Electors In AC"]) * 100

# Bar plot: Average voter turnout by state
plt.figure(figsize=(14, 6))
turnout_by_state = df.groupby("State/Ut Name")["Voter Turnout (%)"].mean().sort_values(ascending=False)
sns.barplot(x=turnout_by_state.index, y=turnout_by_state.values, palette="viridis")
plt.title("Average Voter Turnout by State")
plt.xticks(rotation=90)
plt.ylabel("Turnout (%)")
plt.xlabel("State/UT")
plt.tight_layout()
plt.show()

# ---------------------------
# PARTY-WISE TOTAL VOTES
# ---------------------------
party_votes = df.groupby("Party")["Votes Secured Evm"].sum().sort_values(ascending=False)

# Pie chart: Top 5 parties by total votes
top5 = party_votes.head(5)
others = party_votes[5:].sum()
labels = list(top5.index) + ["Others"]
sizes = list(top5.values) + [others]

plt.figure(figsize=(7, 7))
plt.pie(sizes, labels=labels, autopct="%1.1f%%", startangle=140, colors=sns.color_palette("pastel"))
plt.title("Vote Share of Top 5 Parties")
plt.show()

# ---------------------------
# TOP CANDIDATES PER STATE (by votes)
# ---------------------------
top_candidates = df.loc[df.groupby(["State/Ut Name", "AC Name"])["Votes Secured Evm"].idxmax()]
print("\nTop Candidate Per Assembly Constituency:\n")
print(top_candidates[["State/Ut Name", "AC Name", "Candidate Name", "Party", "Votes Secured Evm"]].head(10))

# ---------------------------
# NOTA VOTES ANALYSIS
# ---------------------------
plt.figure(figsize=(12, 5))
sns.histplot(df["Nota Votes Evm In AC"], bins=30, color="salmon", kde=True)
plt.title("Distribution of NOTA Votes Across Assembly Constituencies")
plt.xlabel("NOTA Votes")
plt.ylabel("Frequency")
plt.show()

# ---------------------------
# BOX PLOT: VOTES DISTRIBUTION BY PARTY (Top 10)
# ---------------------------
top_parties = df["Party"].value_counts().head(10).index
plt.figure(figsize=(14, 6))
sns.boxplot(
    data=df[df["Party"].isin(top_parties)],
    x="Party",
    y="Votes Secured Evm",
    hue="Party",             # ✅ Fix for Seaborn FutureWarning
    palette="Set3",
    legend=False
)
plt.title("Vote Distribution by Party (Top 10)")
plt.xticks(rotation=45)
plt.legend().remove()
plt.show()

# ---------------------------
# CORRELATION HEATMAP FOR NUMERIC FIELDS
# ---------------------------
plt.figure(figsize=(10, 6))
numeric_cols = ["Total Electors In AC", "Votes Secured Evm", "Nota Votes Evm In AC"]
sns.heatmap(df[numeric_cols].corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Between Electors, Votes & NOTA")
plt.show()
